import test from 'node:test';
import assert from 'node:assert/strict';
import { createMessagePolicy } from '../src/policy.js';

const own = '260960516265:3@s.whatsapp.net';
const group = '120363000111@g.us';
function msg(id, patch = {}) {
  return { key: { remoteJid: group, participant: '260977700001@s.whatsapp.net', id, fromMe: false }, message: { extendedTextMessage: { text: 'hello', contextInfo: { mentionedJid: ['260960516265@s.whatsapp.net'] } } }, ...patch };
}
const opts = { groupReplies: true, groups: [{ chatJid: group, participants: ['260977700001@s.whatsapp.net'] }] };

test('group replies require opt-in, exact approved chat and participant, and actual linked-account mention', () => {
  assert.equal(createMessagePolicy()({ userId: 'u', ownJid: own, message: msg('0'), upsertType: 'notify' }), null);
  const mayHandle = createMessagePolicy({ getOptions: () => opts });
  const result = mayHandle({ userId: 'u', ownJid: own, message: msg('1'), upsertType: 'notify' });
  assert.equal(result.chatJid, group);
  assert.equal(result.participantJid, '260977700001@s.whatsapp.net');
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: msg('2', { key: { ...msg('x').key, remoteJid: 'other@g.us' } }), upsertType: 'notify' }), null);
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: msg('3', { key: { ...msg('x').key, participant: '260977700002@s.whatsapp.net' } }), upsertType: 'notify' }), null);
  const noMention = msg('4'); noMention.message.extendedTextMessage.contextInfo.mentionedJid = [];
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: noMention, upsertType: 'notify' }), null);
});

test('literal fallback is separately opt-in and defaults off', () => {
  const literal = msg('lit'); literal.message.extendedTextMessage.text = 'Hi @Henymix, help'; literal.message.extendedTextMessage.contextInfo.mentionedJid = [];
  assert.equal(createMessagePolicy({ getOptions: () => opts })({ userId: 'u', ownJid: own, message: literal, upsertType: 'notify' }), null);
  assert.ok(createMessagePolicy({ getOptions: () => ({ ...opts, literalHenymixFallback: true }) })({ userId: 'u', ownJid: own, message: literal, upsertType: 'notify' }));
});

test('ignore history, self messages, duplicates, empty/status and unapproved DMs', () => {
  const mayHandle = createMessagePolicy({ getOptions: () => ({ ...opts, dmReplies: true, dmChats: ['260977700001@s.whatsapp.net'] }) });
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: msg('hist'), upsertType: 'append' }), null);
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: msg('self', { key: { ...msg('x').key, fromMe: true } }), upsertType: 'notify' }), null);
  assert.ok(mayHandle({ userId: 'u', ownJid: own, message: msg('dupe'), upsertType: 'notify' }));
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: msg('dupe'), upsertType: 'notify' }), null);
  const dm = msg('dm', { key: { remoteJid: '260977700001@s.whatsapp.net', participant: '', id: 'dm', fromMe: false }, message: { conversation: 'hi' } });
  assert.ok(mayHandle({ userId: 'u', ownJid: own, message: dm, upsertType: 'notify' }));
  const notAllowed = { ...dm, key: { ...dm.key, remoteJid: '260977700009@s.whatsapp.net', id: 'no' } };
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: notAllowed, upsertType: 'notify' }), null);
  const selfJid = { ...dm, key: { ...dm.key, remoteJid: own, id: 'selfjid' } };
  assert.equal(mayHandle({ userId: 'u', ownJid: own, message: selfJid, upsertType: 'notify' }), null);
});
