import test from 'node:test';
import assert from 'node:assert/strict';
import { SessionManager } from '../src/session-manager.js';
import { HttpError } from '../src/security.js';

function setup() {
  const data = new Map(), metadata = new Map(), sockets = [];
  const vault = {
    get: async id => data.get(id) || null,
    getMetadata: async id => metadata.get(id) || null,
    initialize: async (id, meta) => { data.set(id, {}); metadata.set(id, { ...meta, updatedAt: new Date().toISOString() }); },
    updateMetadata: async (id, meta) => metadata.set(id, { ...(metadata.get(id) || {}), ...meta, updatedAt: new Date().toISOString() }),
    put: async (id, v) => data.set(id, v),
    delete: async id => { data.delete(id); metadata.delete(id); }
  };
  const socketFactory = async ctx => {
    const sock = { code: `PAIR-${ctx.userId}`, ends: 0, logouts: 0, sends: [],
      requestPairingCode: async () => sock.code,
      end: async () => { sock.ends++; }, logout: async () => { sock.logouts++; },
      sendMessage: async (...args) => sock.sends.push(args), ctx };
    sockets.push(sock); return sock;
  };
  return { manager: new SessionManager({ vault, socketFactory }), data, metadata, vault, sockets };
}

test('pair, status and disconnect are bound to the verified owner id; pairing code is one-time', async () => {
  const { manager, sockets, data } = setup();
  const a = await manager.pair('owner-A', '+260977700001');
  assert.equal(a.pairingCode, 'PAIR-owner-A');
  assert.equal((await manager.status('owner-A')).status, 'pairing');
  assert.deepEqual(await manager.status('owner-B'), { status: 'disconnected' });
  assert.equal('pairingCode' in await manager.status('owner-A'), false);
  assert.equal(sockets.length, 1);
  await manager.disconnect('owner-B');
  assert.equal(sockets[0].ends, 0);
  assert.equal(data.has('owner-A'), true, 'disconnecting another owner must not delete this owner’s record');
  await manager.disconnect('owner-A');
  assert.equal(sockets[0].ends, 1);
  assert.equal(data.has('owner-A'), false);
  assert.deepEqual(await manager.status('owner-A'), { status: 'disconnected' });
});

test('connected owner disconnect logs out only that linked device and removes encrypted session record', async () => {
  const { manager, sockets, data } = setup();
  await manager.pair('owner-A', '+260977700001');
  const s = sockets[0];
  await s.ctx.onCredentials({ creds: { marker: 'opaque' } });
  s.ctx.onConnection({ connection: 'open' });
  assert.equal((await manager.status('owner-A')).status, 'connected');
  await manager.disconnect('owner-A');
  assert.equal(s.logouts, 1);
  assert.equal(s.ends, 1);
  assert.equal(data.has('owner-A'), false);
});

test('phone validation and duplicate pairing fail closed; persisted auth requires owner cleanup before pairing again', async () => {
  const { manager, data } = setup();
  await assert.rejects(manager.pair('u', '260977700001'), e => e instanceof HttpError && e.status === 400);
  await manager.pair('u', '+260977700001');
  await assert.rejects(manager.pair('u', '+260977700002'), e => e instanceof HttpError && e.status === 409);
  await manager.disconnect('u');
  data.set('u', { creds: { marker: 'old linked state' } });
  assert.equal((await manager.status('u')).status, 'needs_disconnect');
  await assert.rejects(manager.pair('u', '+260977700002'), e => e instanceof HttpError && e.status === 409);
  await manager.disconnect('u');
  assert.equal((await manager.status('u')).status, 'disconnected');
});

test('persisted status survives manager restart but never auto-starts or silently relinks a socket', async () => {
  const { manager, vault, metadata, sockets } = setup();
  await manager.pair('owner-A', '+260977700001');
  const oldSession = sockets[0].ctx;
  await oldSession.onCredentials({ creds: { secret: 'ciphered by real vault' } });
  await oldSession.onConnection({ connection: 'open' });
  assert.equal(metadata.get('owner-A').sessionStatus, 'connected');
  const restarted = new SessionManager({ vault, socketFactory: async () => { throw new Error('must not auto-start'); } });
  assert.deepEqual(await restarted.status('owner-A'), {
    status: 'needs_disconnect', storedStatus: 'connected', phone: '+260977700001', updatedAt: metadata.get('owner-A').updatedAt
  });
  await assert.rejects(restarted.pair('owner-A', '+260977700002'), e => e instanceof HttpError && e.status === 409);
  await restarted.disconnect('owner-A');
  assert.equal(metadata.has('owner-A'), false);
  assert.deepEqual(await restarted.status('owner-A'), { status: 'disconnected' });
});

test('no backend means no outbound sends', async () => {
  const { manager, sockets } = setup();
  await manager.pair('u', '+260977700001');
  const s = sockets[0];
  const event = [{ key: { id: '1', remoteJid: 'x@s.whatsapp.net', fromMe: false }, message: { conversation: 'hello' } }];
  await s.ctx.onMessages(event, 'notify', 'me@s.whatsapp.net');
  assert.equal(s.sends.length, 0);
  assert.equal(manager.replyBackend, null);
});

test('only a specifically injected backend can reply after the approved mention policy', async () => {
  const data = new Map(), sends = [];
  const vault = { get: async id => data.get(id) || null, put: async (id, v) => data.set(id, v), delete: async id => data.delete(id) };
  let context;
  const socketFactory = async ctx => { context = ctx; return { requestPairingCode: async () => 'A1B2', sendMessage: async (...a) => sends.push(a), end: async () => {} }; };
  const chat = '120363000111@g.us', participant = '260977700001@s.whatsapp.net';
  const manager = new SessionManager({ vault, socketFactory,
    getOptions: () => ({ groupReplies: true, groups: [{ chatJid: chat, participants: [participant] }] }),
    replyBackend: { reply: async item => `reply to ${item.text}` }
  });
  await manager.pair('u', '+260977700001');
  const message = { key: { id: '1', remoteJid: chat, participant, fromMe: false }, message: { extendedTextMessage: { text: 'hello', contextInfo: { mentionedJid: ['260960516265@s.whatsapp.net'] } } } };
  await context.onMessages([message], 'notify', '260960516265:3@s.whatsapp.net');
  assert.equal(sends.length, 1);
  assert.equal(sends[0][0], chat);
  assert.deepEqual(sends[0][1], { text: 'reply to hello' });
  await context.onMessages([message], 'append', '260960516265:3@s.whatsapp.net');
  assert.equal(sends.length, 1);
});
