import test from 'node:test';
import assert from 'node:assert/strict';
import { createHttpHandler } from '../src/http.js';
import { HttpError, createSupabaseAuth } from '../src/security.js';

async function call(handler, { method = 'GET', url, authorization, contentType, origin, body } = {}) {
  const req = { method, url, headers: { ...(authorization ? { authorization } : {}), ...(contentType ? { 'content-type': contentType } : {}), ...(origin ? { origin } : {}) }, socket: { remoteAddress: 'test-client' },
    async *[Symbol.asyncIterator]() { if (body !== undefined) yield Buffer.from(body); } };
  const res = { writeHead(status, headers) { this.status = status; this.headers = headers; }, end(value) { this.body = value ? JSON.parse(value) : null; } };
  await handler(req, res); return res;
}

test('HTTP contract derives owner from validated bearer; cannot select tenant', async () => {
  const calls = [], sessions = {
    status: id => ({ owner: id, status: 'disconnected' }),
    pair: async (id, phone) => { calls.push(['pair', id, phone]); return { pairingCode: 'TEST-CODE', expiresInSeconds: 120, status: 'pairing' }; },
    disconnect: async id => { calls.push(['disconnect', id]); return { status: 'disconnected' }; }
  };
  const auth = async req => {
    if (req.headers.authorization === 'Bearer token-owner-A') return { userId: 'owner-A' };
    if (req.headers.authorization === 'Bearer token-owner-B') return { userId: 'owner-B' };
    throw new HttpError(401, 'Unauthorized');
  };
  const handler = createHttpHandler({ authenticate: auth, sessions, pairingEnabled: true });
  let r = await call(handler, { url: '/v1/status', authorization: 'Bearer token-owner-A' });
  assert.deepEqual(r.body, { owner: 'owner-A', status: 'disconnected' });
  r = await call(handler, { method: 'POST', url: '/v1/pair', authorization: 'Bearer token-owner-A', contentType: 'application/json', body: JSON.stringify({ phone: '+260977700001', user_id: 'owner-B' }) });
  assert.equal(r.status, 400); assert.equal(calls.length, 0);
  r = await call(handler, { method: 'POST', url: '/v1/pair', authorization: 'Bearer token-owner-A', contentType: 'application/json', body: JSON.stringify({ phone: '+260977700001' }) });
  assert.equal(r.status, 200); assert.equal(r.body.pairingCode, 'TEST-CODE');
  assert.deepEqual(calls[0], ['pair', 'owner-A', '+260977700001']);
  r = await call(handler, { method: 'POST', url: '/v1/disconnect', authorization: 'Bearer token-owner-B' });
  assert.equal(r.status, 200); assert.deepEqual(calls[1], ['disconnect', 'owner-B']);
  r = await call(handler, { method: 'POST', url: '/v1/pair', authorization: 'Bearer bad', contentType: 'application/json', body: '{"phone":"+260977700001"}' });
  assert.equal(r.status, 401);
});

test('CORS is allowlisted to the preview origin; health check is public and does not reveal session data', async () => {
  const origin = 'https://henymix-app-preview.henrymwansa16.workers.dev';
  const handler = createHttpHandler({ allowedOrigin: origin, authenticate: async () => ({ userId: 'owner-A' }), sessions: { status: () => ({ status: 'disconnected' }), pair: async () => ({}), disconnect: async () => ({}) } });
  const preflight = await call(handler, { method: 'OPTIONS', url: '/v1/pair', origin });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers['access-control-allow-origin'], origin);
  assert.match(preflight.headers['access-control-allow-headers'], /authorization/i);
  const wrongOrigin = await call(handler, { url: '/v1/status', origin: 'https://evil.example' });
  assert.equal(wrongOrigin.status, 403);
  const health = await call(handler, { url: '/health' });
  assert.equal(health.status, 200);
  assert.deepEqual(health.body, { status: 'ok' });
});

test('pairing is explicitly disabled by default', async () => {
  const handler = createHttpHandler({ authenticate: async () => ({ userId: 'u' }), sessions: { status: () => ({}), pair: async () => { throw new Error('must not reach'); }, disconnect: async () => ({}) } });
  const r = await call(handler, { method: 'POST', url: '/v1/pair', contentType: 'application/json', body: JSON.stringify({ phone: '+260977700001' }) });
  assert.equal(r.status, 503);
});

test('Supabase Auth uses only anon key and verified user response, not decoded JWT claims', async () => {
  let captured;
  const auth = createSupabaseAuth({ supabaseUrl: 'https://example.supabase.co', anonKey: 'public-anon', fetchImpl: async (url, options) => {
    captured = { url: String(url), options };
    return { ok: true, json: async () => ({ id: '11111111-2222-4333-8444-555555555555', aud: 'authenticated' }) };
  } });
  const result = await auth({ headers: { authorization: 'Bearer eyJhbGciOiJub25lIn0.eyJzdWIiOiJmYWtlIn0.fake' } });
  assert.equal(result.userId, '11111111-2222-4333-8444-555555555555');
  assert.equal(captured.url, 'https://example.supabase.co/auth/v1/user');
  assert.deepEqual(captured.options.headers, { apikey: 'public-anon', authorization: 'Bearer eyJhbGciOiJub25lIn0.eyJzdWIiOiJmYWtlIn0.fake' });
  assert.equal(captured.options.headers.apikey.includes('service'), false);
});
