import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { SupabaseEncryptedVault } from '../src/security.js';

const ownerA = '11111111-2222-4333-8444-555555555555';
const ownerB = 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee';
const key = randomBytes(32).toString('base64');
const serviceKey = 'test-service-role-secret';

function response(status, payload = null) {
  return { ok: status >= 200 && status < 300, status, json: async () => payload };
}
function createDbFetch() {
  const calls = [], rows = new Map();
  const fetchImpl = async (urlArg, options) => {
    const url = new URL(urlArg); const method = options.method;
    calls.push({ url: String(url), method, headers: options.headers, body: options.body });
    const owner = url.searchParams.get('owner_id')?.slice(3);
    if (url.pathname !== '/rest/v1/henymix_whatsapp_vault') return response(400);
    if (method === 'POST') { const row = JSON.parse(options.body); if (url.searchParams.get('on_conflict') !== 'owner_id') return response(400); rows.set(row.owner_id, row); return response(201); }
    if (!owner) return response(400);
    if (method === 'GET') return response(200, rows.has(owner) ? [rows.get(owner)] : []);
    if (method === 'PATCH') {
      if (rows.has(owner)) rows.set(owner, { ...rows.get(owner), ...JSON.parse(options.body) });
      return response(204);
    }
    if (method === 'DELETE') { rows.delete(owner); return response(204); }
    return response(405);
  };
  return { fetchImpl, calls, rows };
}

function newVault(fetchImpl) {
  return new SupabaseEncryptedVault({ supabaseUrl: 'https://syxibiyrbgwsgghwwgej.supabase.co', serviceRoleKey: serviceKey, keyBase64: key, fetchImpl });
}

test('exact REST auth, owner-scoped requests, metadata separation, encrypted state round-trip and one-owner DELETE', async () => {
  const { fetchImpl, calls, rows } = createDbFetch();
  const vault = newVault(fetchImpl);
  const authState = { creds: { privateKey: 'VERY-SECRET-CREDENTIAL' }, keys: { session: { secret: 'PRIVATE-BAILEYS-KEY' } } };

  await vault.initialize(ownerA, { phoneNumber: '+260977700001', sessionStatus: 'pairing' });
  const init = calls.at(-1);
  assert.equal(init.method, 'POST');
  assert.equal(init.url, 'https://syxibiyrbgwsgghwwgej.supabase.co/rest/v1/henymix_whatsapp_vault?on_conflict=owner_id');
  assert.deepEqual(init.headers, {
    apikey: serviceKey, authorization: `Bearer ${serviceKey}`, 'content-type': 'application/json',
    prefer: 'resolution=merge-duplicates,return=minimal'
  });
  assert.deepEqual(Object.keys(JSON.parse(init.body)).sort(), ['encrypted_state', 'owner_id', 'phone_number', 'session_status', 'updated_at']);
  assert.equal(JSON.parse(init.body).phone_number, '+260977700001');
  assert.equal(JSON.parse(init.body).session_status, 'pairing');
  assert.equal(JSON.stringify(init.body).includes('VERY-SECRET'), false);

  const cipherText = rows.get(ownerA).encrypted_state;
  assert.match(cipherText, /^v1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$/);
  assert.equal(cipherText.includes('VERY-SECRET-CREDENTIAL'), false);
  assert.equal(cipherText.includes('PRIVATE-BAILEYS-KEY'), false);
  assert.deepEqual(await vault.get(ownerA), {});
  const initialRead = calls.at(-1);
  assert.equal(initialRead.method, 'GET');
  assert.equal(initialRead.url, `https://syxibiyrbgwsgghwwgej.supabase.co/rest/v1/henymix_whatsapp_vault?owner_id=eq.${ownerA}&select=encrypted_state`);
  assert.equal(vault.serviceRoleKey, undefined);
  assert.equal(vault.encryptionKey, undefined);
  await vault.put(ownerA, authState);
  const put = calls.at(-1);
  assert.equal(put.method, 'PATCH');
  assert.equal(put.url, `https://syxibiyrbgwsgghwwgej.supabase.co/rest/v1/henymix_whatsapp_vault?owner_id=eq.${ownerA}&select=owner_id`);
  assert.equal(put.headers.prefer, 'return=minimal');
  const putBody = JSON.parse(put.body);
  assert.deepEqual(Object.keys(putBody).sort(), ['encrypted_state', 'updated_at']);
  assert.notEqual(putBody.encrypted_state, JSON.stringify(authState));
  assert.equal(put.body.includes('VERY-SECRET-CREDENTIAL'), false);
  assert.deepEqual(await vault.get(ownerA), authState);

  await vault.updateMetadata(ownerA, { phoneNumber: '+260977700001', sessionStatus: 'connected' });
  const metadata = calls.at(-1);
  assert.equal(metadata.method, 'PATCH');
  assert.deepEqual(Object.keys(JSON.parse(metadata.body)).sort(), ['phone_number', 'session_status', 'updated_at']);
  assert.deepEqual(await vault.getMetadata(ownerA).then(({ phoneNumber, sessionStatus }) => ({ phoneNumber, sessionStatus })), { phoneNumber: '+260977700001', sessionStatus: 'connected' });
  assert.equal(calls.at(-1).url, `https://syxibiyrbgwsgghwwgej.supabase.co/rest/v1/henymix_whatsapp_vault?owner_id=eq.${ownerA}&select=phone_number%2Csession_status%2Cupdated_at`);
  assert.deepEqual(await vault.get(ownerB), null);

  await vault.initialize(ownerB, { phoneNumber: '+260977700002', sessionStatus: 'pairing' });
  await vault.delete(ownerA);
  const deletion = calls.at(-1);
  assert.equal(deletion.method, 'DELETE');
  assert.equal(deletion.url, `https://syxibiyrbgwsgghwwgej.supabase.co/rest/v1/henymix_whatsapp_vault?owner_id=eq.${ownerA}&select=owner_id`);
  assert.equal(rows.has(ownerA), false);
  assert.equal(rows.has(ownerB), true);
  assert.deepEqual(await vault.get(ownerB), {});
  for (const call of calls) {
    if (call.method === 'POST') {
      const posted = JSON.parse(call.body);
      assert.ok([ownerA, ownerB].includes(posted.owner_id));
    } else {
      assert.equal(new URL(call.url).searchParams.get('owner_id'), `eq.${call.url.includes(ownerB) ? ownerB : ownerA}`);
    }
    assert.equal(call.headers.apikey, serviceKey);
    assert.equal(call.headers.authorization, `Bearer ${serviceKey}`);
    assert.equal(call.url.includes(serviceKey), false);
  }
});

test('AAD binds ciphertext to owner; tamper and bad keys fail closed', async () => {
  const { fetchImpl, rows } = createDbFetch();
  const vault = newVault(fetchImpl);
  await vault.initialize(ownerA, { phoneNumber: null, sessionStatus: 'pairing' });
  const state = { creds: { token: 'owner-bound-value' } };
  await vault.put(ownerA, state);
  const ciphertext = rows.get(ownerA).encrypted_state;
  assert.throws(() => vault.decrypt(ciphertext, ownerB), /authentication failed/);
  const parts = ciphertext.split('.');
  parts[2] = `${parts[2][0] === 'A' ? 'B' : 'A'}${parts[2].slice(1)}`;
  rows.get(ownerA).encrypted_state = parts.join('.');
  await assert.rejects(vault.get(ownerA), /authentication failed/);
  assert.throws(() => new SupabaseEncryptedVault({ supabaseUrl: 'https://example.supabase.co', serviceRoleKey: 'never-log', keyBase64: 'not-a-key', fetchImpl }), /32-byte key/);
});

test('REST failures are generic and do not leak upstream response details or secrets', async () => {
  const vault = newVault(async () => response(403, { message: `denied ${serviceKey}` }));
  await assert.rejects(vault.get(ownerA), error => error.message === 'Vault request failed (403)' && !error.message.includes(serviceKey));
  const offline = newVault(async () => { throw new Error(`network ${serviceKey}`); });
  await assert.rejects(offline.get(ownerA), error => error.message === 'Vault service unavailable' && !error.message.includes(serviceKey));
});

test('vault refuses invalid owner filters and unsupported metadata status', async () => {
  const { fetchImpl, calls } = createDbFetch(); const vault = newVault(fetchImpl);
  await assert.rejects(vault.get('owner-A'), /Invalid vault owner id/);
  await assert.rejects(vault.updateMetadata(ownerA, { sessionStatus: 'active' }), /Invalid session status/);
  assert.equal(calls.length, 0);
});
