const normalizeJid = jid => typeof jid === 'string' ? jid.replace(/:\d+(?=@)/, '').toLowerCase() : '';

export function extractText(message = {}) {
  const m = message.message || {};
  return m.conversation ?? m.extendedTextMessage?.text ?? m.imageMessage?.caption ??
    m.videoMessage?.caption ?? m.documentMessage?.caption ?? m.buttonsResponseMessage?.selectedDisplayText ??
    m.listResponseMessage?.title ?? '';
}
function mentionedJids(message = {}) {
  const m = message.message || {};
  const ctx = m.extendedTextMessage?.contextInfo || m.imageMessage?.contextInfo ||
    m.videoMessage?.contextInfo || m.documentMessage?.contextInfo || {};
  return (ctx.mentionedJid || []).map(normalizeJid);
}

export function createMessagePolicy({ getOptions = () => ({}) } = {}) {
  const seen = new Map();
  const ttlMs = 10 * 60 * 1000, maxSeen = 5000;
  return function mayHandle({ userId, ownJid, message, upsertType }) {
    if (upsertType !== 'notify' || !userId || !message?.key || message.key.fromMe) return null;
    const chat = message.key.remoteJid || '';
    const participant = message.key.participant || message.participant || '';
    const normalizedOwn = normalizeJid(ownJid);
    const normalizedParticipant = normalizeJid(participant);
    if (!normalizedOwn || !chat || !message.key.id || chat === 'status@broadcast' || chat.endsWith('@broadcast')) return null;
    if (normalizedParticipant && normalizedParticipant === normalizedOwn) return null;
    const id = `${userId}\0${chat}\0${message.key.id}`;
    const now = Date.now();
    for (const [key, exp] of seen) if (exp <= now) seen.delete(key);
    if (seen.has(id)) return null;
    seen.set(id, now + ttlMs);
    if (seen.size > maxSeen) seen.delete(seen.keys().next().value);
    const text = extractText(message).trim();
    if (!text) return null;
    const opts = getOptions(userId) || {};
    const isGroup = chat.endsWith('@g.us');
    if (isGroup) {
      if (opts.groupReplies !== true || !Array.isArray(opts.groups)) return null;
      if (!normalizedParticipant) return null;
      const approvedGroup = opts.groups.find(g => g?.chatJid === chat && Array.isArray(g.participants) && g.participants.some(jid => normalizeJid(jid) === normalizedParticipant));
      if (!approvedGroup) return null;
      const realMention = mentionedJids(message).includes(normalizedOwn);
      const fallback = opts.literalHenymixFallback === true && /(^|\s)@Henymix(?=$|\s|[.,!?])/i.test(text);
      if (!realMention && !fallback) return null;
    } else {
      if (opts.dmReplies !== true || !Array.isArray(opts.dmChats) || !opts.dmChats.includes(chat) || !chat.endsWith('@s.whatsapp.net') || normalizeJid(chat) === normalizedOwn) return null;
    }
    return Object.freeze({ userId, chatJid: chat, participantJid: participant, messageId: message.key.id, text, isGroup });
  };
}
