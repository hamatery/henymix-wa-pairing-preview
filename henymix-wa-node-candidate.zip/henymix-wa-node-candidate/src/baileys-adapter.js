// Optional real Baileys adapter. Tests inject a fake socket factory and never load this module.
export async function createBaileysSocketFactory({ vault }) {
  const b = await import('@whiskeysockets/baileys');
  const makeWASocket = b.default || b.makeWASocket;
  if (!makeWASocket) throw new Error('Baileys socket factory unavailable');
  const bufferJSON = b.BufferJSON;
  const { initAuthCreds } = b;
  const { default: pino } = await import('pino');
  const silentLogger = pino({ level: 'silent' });
  return async function socketFactory({ userId, onCredentials, onConnection, onMessages }) {
    let stored = await vault.get(userId);
    if (stored) stored = JSON.parse(JSON.stringify(stored), bufferJSON?.reviver);
    let creds = stored?.creds || initAuthCreds();
    const keyData = stored?.keys || {};
    let saveQueue = Promise.resolve();
    const persist = () => {
      const normalized = JSON.parse(JSON.stringify({ creds, keys: keyData }, bufferJSON?.replacer));
      saveQueue = saveQueue.then(() => onCredentials(normalized));
      return saveQueue;
    };
    const keys = {
      get: async (type, ids) => {
        const values = {};
        for (const id of ids) {
          let value = keyData[type]?.[id];
          if (value && type === 'app-state-sync-key') value = b.proto.Message.AppStateSyncKeyData.fromObject(value);
          if (value !== undefined) values[id] = value;
        }
        return values;
      },
      set: async data => {
        for (const [type, entries] of Object.entries(data || {})) {
          keyData[type] ||= {};
          for (const [id, value] of Object.entries(entries || {})) {
            if (value == null) delete keyData[type][id]; else keyData[type][id] = value;
          }
        }
        await persist();
      }
    };
    const socket = makeWASocket({
      auth: { creds, keys }, logger: silentLogger, printQRInTerminal: false, syncFullHistory: false,
      markOnlineOnConnect: false, shouldIgnoreJid: jid => jid === 'status@broadcast'
    });
    socket.ev.on('creds.update', async update => {
      Object.assign(creds, update);
      try { await persist(); } catch { /* no credential data in diagnostics */ }
    });
    socket.ev.on('connection.update', update => { void Promise.resolve(onConnection(update)).catch(() => {}); });
    socket.ev.on('messages.upsert', ({ messages, type }) => {
      const ownJid = socket.user?.id || creds.me?.id || '';
      void onMessages(messages || [], type, ownJid);
    });
    // Only lifecycle operations are exposed; callers may send solely through the guarded reply path.
    return {
      requestPairingCode: phone => socket.requestPairingCode(phone),
      sendMessage: (jid, content, options) => socket.sendMessage(jid, content, options),
      end: reason => socket.end(reason),
      logout: () => socket.logout()
    };
  };
}
