import { safePhone, HttpError } from './security.js';
import { createMessagePolicy } from './policy.js';

export class SessionManager {
  constructor({ vault, socketFactory, replyBackend = null, getOptions = () => ({}), pairingCodeTtlMs = 120_000 }) {
    this.vault = vault;
    this.socketFactory = socketFactory;
    this.replyBackend = replyBackend;
    this.pairingCodeTtlMs = pairingCodeTtlMs;
    this.sessions = new Map();
    this.mayHandle = createMessagePolicy({ getOptions });
  }
  async status(userId) {
    const session = this.sessions.get(userId);
    if (session) return { status: session.status, paired: session.paired, connected: session.connected, phone: session.phone, updatedAt: session.updatedAt };
    const metadata = await this.vault.getMetadata?.(userId);
    if (metadata) {
      // Stored auth state is not a live socket after restart. Never auto-restore/relink;
      // the owner has to explicitly disconnect before starting another pairing.
      return { status: 'needs_disconnect', storedStatus: metadata.sessionStatus, phone: metadata.phoneNumber ?? undefined, updatedAt: metadata.updatedAt };
    }
    return { status: await this.vault.get(userId) ? 'needs_disconnect' : 'disconnected' };
  }
  async saveMetadata(userId, session) {
    if (this.vault.updateMetadata) {
      await this.vault.updateMetadata(userId, { phoneNumber: session.phone, sessionStatus: session.status });
    }
  }
  async updateStatus(userId, session, status) {
    session.status = status;
    session.connected = status === 'connected';
    session.paired = session.paired || status === 'connected';
    session.updatedAt = new Date().toISOString();
    try { await this.saveMetadata(userId, session); } catch { /* Never log state, phone, credentials, or codes. */ }
  }
  async pair(userId, phoneValue) {
    if (this.sessions.has(userId)) throw new HttpError(409, 'A WhatsApp session already exists; disconnect it first');
    const phone = safePhone(phoneValue);
    const auth = await this.vault.get(userId);
    if (auth) throw new HttpError(409, 'Stored WhatsApp credentials exist; disconnect before pairing again');
    const session = { status: 'pairing', paired: false, connected: false, phone: `+${phone}`, updatedAt: new Date().toISOString(), socket: null, codeExpiresAt: 0 };
    this.sessions.set(userId, session);
    try {
      if (this.vault.initialize) {
        await this.vault.initialize(userId, { phoneNumber: session.phone, sessionStatus: session.status });
      } else {
        await this.vault.put(userId, {});
      }
      const socket = await this.socketFactory({
        userId, authState: auth,
        onCredentials: async next => {
          if (this.sessions.get(userId) === session && session.status !== 'disconnected') await this.vault.put(userId, next);
        },
        onConnection: update => {
          if (update?.connection === 'open') void this.updateStatus(userId, session, 'connected');
          if (update?.connection === 'close' && session.status !== 'disconnected') void this.updateStatus(userId, session, 'disconnected');
        },
        onMessages: (messages, type, ownJid) => this.handleMessages(userId, messages, type, ownJid)
      });
      session.socket = socket;
      const code = await socket.requestPairingCode(phone);
      if (typeof code !== 'string' || !code || code.length > 32) throw new Error('Pairing code was not returned');
      session.codeExpiresAt = Date.now() + this.pairingCodeTtlMs;
      session.updatedAt = new Date().toISOString();
      // The one-time pairing code is returned only here and is never persisted/logged.
      return { pairingCode: code, expiresInSeconds: Math.floor(this.pairingCodeTtlMs / 1000), status: session.status };
    } catch {
      this.sessions.delete(userId);
      try { await session.socket?.end?.(new Error('pair flow failed')); } catch { /* best effort */ }
      try { await this.vault.delete(userId); } catch { /* best effort */ }
      throw new HttpError(502, 'Pairing could not be started');
    }
  }
  async handleMessages(userId, messages, upsertType, ownJid) {
    const session = this.sessions.get(userId);
    if (!session || session.status === 'disconnected' || !Array.isArray(messages)) return;
    for (const message of messages) {
      const accepted = this.mayHandle({ userId, ownJid, message, upsertType });
      if (!accepted || !this.replyBackend) continue;
      try {
        const answer = await this.replyBackend.reply(Object.freeze({ ...accepted }));
        const text = typeof answer === 'string' ? answer : answer?.text;
        if (typeof text === 'string' && text.trim() && text.length <= 4000 && session.socket?.sendMessage) {
          await session.socket.sendMessage(accepted.chatJid, { text: text.trim() }, { quoted: message });
        }
      } catch { /* Never log user messages, responses, tokens, auth state, or pairing codes. */ }
    }
  }
  async disconnect(userId) {
    const session = this.sessions.get(userId);
    if (session) {
      session.status = 'disconnected'; session.connected = false; session.updatedAt = new Date().toISOString();
      this.sessions.delete(userId);
      try {
        if (session.paired && session.socket?.logout) {
          await session.socket.logout();
          await session.socket?.end?.(new Error('owner disconnected'));
        } else await session.socket?.end?.(new Error('owner disconnected'));
      } catch { /* best effort */ }
    }
    // RLS has no client policies; this is a server-side, owner_id-filtered DELETE.
    await this.vault.delete(userId);
    return { status: 'disconnected' };
  }
}
