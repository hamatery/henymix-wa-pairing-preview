import { createSupabaseAuth, SupabaseEncryptedVault } from './security.js';
import { SessionManager } from './session-manager.js';
import { createServer } from 'node:http';
import { createHttpHandler } from './http.js';

const enabled = process.env.ENABLE_PAIRING === 'true';
const cleanEnv = value => String(value || '').trim().replace(/^[\"']+|[\"']+$/g, '').trim();
const supabaseUrl = cleanEnv(process.env.SUPABASE_URL);
const anonKey = cleanEnv(process.env.SUPABASE_ANON_KEY);
const serviceRoleKey = cleanEnv(process.env.SUPABASE_SERVICE_ROLE_KEY);
const key = cleanEnv(process.env.SESSION_ENCRYPTION_KEY);
const webOrigin = cleanEnv(process.env.WEB_ORIGIN);
if (!supabaseUrl || !anonKey || !serviceRoleKey || !key || !webOrigin) {
  process.stderr.write('Startup refused: required auth and encrypted vault configuration is missing.\n');
  process.exit(1);
}
if (anonKey === serviceRoleKey || key === anonKey || key === serviceRoleKey) {
  process.stderr.write('Startup refused: auth, service-role, and encryption secrets must be distinct.\n');
  process.exit(1);
}
let auth, vault;
try {
  auth = createSupabaseAuth({ supabaseUrl, anonKey });
  vault = new SupabaseEncryptedVault({ supabaseUrl, serviceRoleKey, keyBase64: key });
  const origin = new URL(webOrigin);
  if (origin.protocol !== 'https:' || origin.origin !== webOrigin) throw new Error('WEB_ORIGIN must be one HTTPS origin');
} catch (error) {
  const message = String(error?.message || '');
  const safeReason = /SESSION_ENCRYPTION_KEY/.test(message) ? 'encryption-key-format' : /Supabase URL must use HTTPS/.test(message) ? 'supabase-url-format' : /WEB_ORIGIN/.test(message) ? 'preview-origin-format' : /required/.test(message) ? 'missing-required-setting' : 'configuration-invalid';
  const keyBytes = Buffer.from(key, 'base64');
  const originValid = (() => { try { const parsed = new URL(webOrigin); return parsed.protocol === 'https:' && parsed.origin === webOrigin; } catch { return false; } })();
  process.stderr.write(`Startup refused: ${safeReason}; SUPABASE_URL=${Boolean(supabaseUrl)}; SUPABASE_ANON_KEY=${Boolean(anonKey)}; SUPABASE_SERVICE_ROLE_KEY=${Boolean(serviceRoleKey)}; SESSION_ENCRYPTION_KEY_32_BYTES=${keyBytes.length === 32}; WEB_ORIGIN_VALID=${originValid}.\n`);
  process.exit(1);
}
let socketFactory = async () => { throw new Error('Pairing disabled'); };
if (enabled) {
  try {
    const { createBaileysSocketFactory } = await import('./baileys-adapter.js');
    socketFactory = await createBaileysSocketFactory({ vault });
  } catch {
    process.stderr.write('Startup refused: Baileys adapter could not be initialized.\n');
    process.exit(1);
  }
}
// No assistant implementation is wired. Deployments must inject a separately reviewed,
// owner-bound backend adapter; leaving it null guarantees no unsolicited replies.
const sessions = new SessionManager({ vault, socketFactory, replyBackend: null });
const server = createServer(createHttpHandler({ authenticate: auth, sessions, pairingEnabled: enabled, allowedOrigin: webOrigin }));
const port = Number(process.env.PORT || 3000);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  process.stderr.write('Startup refused: invalid PORT.\n'); process.exit(1);
}
server.listen(port, '0.0.0.0', () => {
  // Never log request data, credentials, pairing codes, or auth/session state.
  process.stdout.write('Henymix Node candidate is listening; no WhatsApp session is auto-started.\n');
});
