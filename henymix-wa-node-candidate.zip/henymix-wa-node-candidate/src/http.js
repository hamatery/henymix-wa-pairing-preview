import { HttpError } from './security.js';

function send(res, status, body, cors = {}) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store',
    'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'none'; frame-ancestors 'none'", ...cors
  });
  res.end(JSON.stringify(body));
}
async function bodyJson(req) {
  const chunks = []; let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 4096) throw new HttpError(413, 'Request too large');
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new HttpError(400, 'Invalid JSON'); }
}

export function createHttpHandler({ authenticate, sessions, pairingEnabled = false, allowedOrigin = '', clock = Date.now }) {
  const limits = new Map();
  return async (req, res) => {
    const origin = req.headers.origin || '';
    if (origin && origin !== allowedOrigin) return send(res, 403, { error: 'Origin not allowed' });
    const cors = origin === allowedOrigin && origin ? {
      'access-control-allow-origin': allowedOrigin,
      'access-control-allow-methods': 'GET, POST, OPTIONS',
      'access-control-allow-headers': 'authorization, content-type',
      'access-control-max-age': '600',
      'vary': 'Origin'
    } : {};
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'cache-control': 'no-store', ...cors });
      return res.end();
    }
    if (req.method === 'GET' && req.url === '/health') return send(res, 200, { status: 'ok' }, cors);
    const ip = req.socket?.remoteAddress || 'unknown';
    const now = clock();
    let count = limits.get(ip) || [];
    count = count.filter(t => now - t < 60_000);
    if (count.length >= 30) return send(res, 429, { error: 'Too many requests' }, cors);
    count.push(now); limits.set(ip, count);
    try {
      const owner = await authenticate(req);
      if (req.method === 'GET' && req.url === '/v1/status') return send(res, 200, await sessions.status(owner.userId), cors);
      if (req.method === 'POST' && req.url === '/v1/pair') {
        if (!pairingEnabled) throw new HttpError(503, 'Pairing is disabled');
        if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'Content-Type must be application/json');
        const body = await bodyJson(req);
        if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(k => k !== 'phone')) throw new HttpError(400, 'Only phone is accepted');
        return send(res, 200, await sessions.pair(owner.userId, body.phone), cors);
      }
      if (req.method === 'POST' && req.url === '/v1/disconnect') return send(res, 200, await sessions.disconnect(owner.userId), cors);
      return send(res, 404, { error: 'Not found' }, cors);
    } catch (error) {
      if (error instanceof HttpError) return send(res, error.status, { error: error.message }, cors);
      return send(res, 500, { error: 'Request failed' }, cors);
    }
  };
}
