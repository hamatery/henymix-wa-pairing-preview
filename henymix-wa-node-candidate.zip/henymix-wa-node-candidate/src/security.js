import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';

export class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

// Validate access tokens by asking Supabase Auth itself. Never trust decoded JWT claims
// supplied by a client, and never use a client-supplied user_id/tenant_id.
export function createSupabaseAuth({ supabaseUrl, anonKey, fetchImpl = fetch }) {
  if (!supabaseUrl || !anonKey) throw new Error('Supabase Auth configuration is required');
  const base = new URL(supabaseUrl);
  if (base.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(base.hostname)) {
    throw new Error('Supabase URL must use HTTPS');
  }
  return async function authenticate(req) {
    const header = req.headers.authorization || '';
    const match = /^Bearer ([A-Za-z0-9._~-]{20,8192})$/.exec(header);
    if (!match) throw new HttpError(401, 'Unauthorized');
    let response;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
      response = await fetchImpl(new URL('/auth/v1/user', base), {
        method: 'GET', headers: { apikey: anonKey, authorization: `Bearer ${match[1]}` },
        signal: controller.signal
      });
    } catch { throw new HttpError(503, 'Authentication unavailable'); }
    finally { clearTimeout(timeout); }
    if (!response.ok) throw new HttpError(401, 'Unauthorized');
    let user;
    try { user = await response.json(); } catch { throw new HttpError(401, 'Unauthorized'); }
    const userId = typeof user?.id === 'string' && /^[0-9a-f-]{36}$/i.test(user.id) ? user.id : null;
    if (!userId || user?.aud && user.aud !== 'authenticated') throw new HttpError(401, 'Unauthorized');
    return Object.freeze({ userId });
  };
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const VALID_STATUS = new Set(['pairing', 'connected', 'disconnected']);

// Service-role PostgREST adapter. The service key is only accepted by this server-side
// module, sent in authorization/apikey headers, and is never returned or logged. It must
// be provided through the deployment environment and is deliberately distinct from the
// AES key and public Auth anon key.
export class SupabaseEncryptedVault {
  #serviceRoleKey;
  #encryptionKey;
  constructor({ supabaseUrl, serviceRoleKey, keyBase64, fetchImpl = fetch }) {
    if (!supabaseUrl || !serviceRoleKey || !keyBase64) {
      throw new Error('Supabase URL, service-role key and SESSION_ENCRYPTION_KEY are required');
    }
    const base = new URL(supabaseUrl);
    if (base.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(base.hostname)) {
      throw new Error('Supabase URL must use HTTPS');
    }
    if (serviceRoleKey === keyBase64) throw new Error('SESSION_ENCRYPTION_KEY must be distinct from the service-role key');
    const key = Buffer.from(keyBase64, 'base64');
    if (key.length !== 32 || key.toString('base64').replace(/=+$/, '') !== keyBase64.replace(/=+$/, '')) {
      throw new Error('SESSION_ENCRYPTION_KEY must be a base64-encoded 32-byte key');
    }
    this.endpoint = new URL('/rest/v1/henymix_whatsapp_vault', base);
    this.#serviceRoleKey = serviceRoleKey;
    this.#encryptionKey = key;
    this.fetchImpl = fetchImpl;
  }
  ownerUrl(userId, select = 'encrypted_state') {
    if (typeof userId !== 'string' || !UUID.test(userId)) throw new Error('Invalid vault owner id');
    const url = new URL(this.endpoint);
    url.searchParams.set('owner_id', `eq.${userId}`);
    url.searchParams.set('select', select);
    return url;
  }
  #headers(extra = {}) {
    return { apikey: this.#serviceRoleKey, authorization: `Bearer ${this.#serviceRoleKey}`, ...extra };
  }
  encrypt(value, userId) {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', this.#encryptionKey, iv);
    cipher.setAAD(Buffer.from(userId));
    const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
    return `v1.${iv.toString('base64url')}.${cipher.getAuthTag().toString('base64url')}.${ciphertext.toString('base64url')}`;
  }
  decrypt(value, userId) {
    if (typeof value !== 'string') throw new Error('Encrypted session record invalid');
    const [version, ivText, tagText, bodyText, extra] = value.split('.');
    if (version !== 'v1' || !ivText || !tagText || bodyText === undefined || extra !== undefined) throw new Error('Encrypted session record invalid');
    try {
      const decipher = createDecipheriv('aes-256-gcm', this.#encryptionKey, Buffer.from(ivText, 'base64url'));
      decipher.setAAD(Buffer.from(userId));
      decipher.setAuthTag(Buffer.from(tagText, 'base64url'));
      return JSON.parse(Buffer.concat([decipher.update(Buffer.from(bodyText, 'base64url')), decipher.final()]).toString('utf8'));
    } catch { throw new Error('Encrypted session record authentication failed'); }
  }
  async request(url, options) {
    let response;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    try { response = await this.fetchImpl(url, { ...options, signal: controller.signal, redirect: 'error' }); }
    catch { throw new Error('Vault service unavailable'); }
    finally { clearTimeout(timeout); }
    if (!response.ok) throw new Error(`Vault request failed (${response.status})`);
    return response;
  }
  async getRow(userId, select = 'encrypted_state') {
    const response = await this.request(this.ownerUrl(userId, select), { method: 'GET', headers: this.#headers({ accept: 'application/json' }) });
    let rows;
    try { rows = await response.json(); } catch { throw new Error('Vault response invalid'); }
    if (!Array.isArray(rows) || rows.length > 1) throw new Error('Vault response invalid');
    return rows[0] || null;
  }
  async get(userId) {
    const row = await this.getRow(userId);
    return row ? this.decrypt(row.encrypted_state, userId) : null;
  }
  async getMetadata(userId) {
    const row = await this.getRow(userId, 'phone_number,session_status,updated_at');
    return row ? { phoneNumber: row.phone_number, sessionStatus: row.session_status, updatedAt: row.updated_at } : null;
  }
  async put(userId, value) {
    const response = await this.request(this.ownerUrl(userId, 'owner_id'), { method: 'PATCH', headers: this.#headers({ 'content-type': 'application/json', prefer: 'return=minimal' }), body: JSON.stringify({ encrypted_state: this.encrypt(value, userId), updated_at: new Date().toISOString() }) });
    return response;
  }
  async initialize(userId, { phoneNumber, sessionStatus = 'pairing' }) {
    return this.upsert(userId, this.encrypt({}, userId), phoneNumber, sessionStatus);
  }
  async updateMetadata(userId, { phoneNumber, sessionStatus }) {
    if (!VALID_STATUS.has(sessionStatus)) throw new Error('Invalid session status');
    if (phoneNumber !== undefined && phoneNumber !== null && (typeof phoneNumber !== 'string' || phoneNumber.length > 16)) throw new Error('Invalid phone metadata');
    const body = { session_status: sessionStatus, updated_at: new Date().toISOString() };
    if (phoneNumber !== undefined) body.phone_number = phoneNumber;
    return this.request(this.ownerUrl(userId, 'owner_id'), { method: 'PATCH', headers: this.#headers({ 'content-type': 'application/json', prefer: 'return=minimal' }), body: JSON.stringify(body) });
  }
  async upsert(userId, encryptedState, phoneNumber, sessionStatus) {
    if (typeof userId !== 'string' || !UUID.test(userId)) throw new Error('Invalid vault owner id');
    if (!VALID_STATUS.has(sessionStatus)) throw new Error('Invalid session status');
    const body = { owner_id: userId, encrypted_state: encryptedState, phone_number: phoneNumber ?? null, session_status: sessionStatus, updated_at: new Date().toISOString() };
    const url = new URL(this.endpoint);
    url.searchParams.set('on_conflict', 'owner_id');
    return this.request(url, { method: 'POST', headers: this.#headers({ 'content-type': 'application/json', prefer: 'resolution=merge-duplicates,return=minimal' }), body: JSON.stringify(body) });
  }
  async delete(userId) {
    return this.request(this.ownerUrl(userId, 'owner_id'), { method: 'DELETE', headers: this.#headers({ prefer: 'return=minimal' }) });
  }
}

export function safePhone(value) {
  if (typeof value !== 'string' || !/^\+[1-9]\d{7,14}$/.test(value)) throw new HttpError(400, 'phone must be in E.164 format');
  return value.slice(1);
}
