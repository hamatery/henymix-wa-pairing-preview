# Henymix WhatsApp linked-device worker — Node candidate

A new, isolated Node.js candidate for review. **Not deployed** and never connected to WhatsApp in this work. It does not modify the existing `henymix-wa-worker` repo, Render, Supabase, production, or the prior Python candidate. The Baileys adapter is implemented but was not run with a real WhatsApp account. No pairing or message was made. No schema change or purchase occurred.

## What is included

- Node 20+ / Render-compatible HTTP worker, with `@whiskeysockets/baileys` pinned to `6.7.24` (the registry’s legacy 6.x tag as of this review; 6.7.18 was rejected after npm reported a critical message-spoofing advisory).
- Pairing, status and disconnect API; Supabase Auth `/auth/v1/user` validation derives owner identity from the verified response. No `user_id`/tenant parameter is accepted.
- Dependency-injected session lifecycle plus an offline fake socket test seam.
- AES-256-GCM encrypted per-owner Supabase REST vault backed by `public.henymix_whatsapp_vault`. Auth state is encrypted before it leaves the process; the table receives only a versioned IV/tag/ciphertext envelope in `encrypted_state`. The encryption key and Supabase `service_role` key are distinct server-side environment secrets. Phone and constrained session status are stored as separate metadata. No use of the existing `whatsapp_sessions` schema or its `auth_state`.
- Group/DM policy gate and an optional assistant-backend interface. Production composition intentionally sets `replyBackend: null`: it cannot answer or send until a separately reviewed backend is wired in. No legacy `yumilo-assistant` endpoint is assumed.
- No `/send` or arbitrary-send API, no CORS, bounded JSON, simple request throttling, security response headers, generic server errors, silent Baileys logger and no request/session/code logging.

## Local tests

Using Node.js 20 or later:

```sh
npm test
```

Offline tests use fake auth/session/socket dependencies and a fake PostgREST fetch. They cover exact owner-filtered REST methods/headers/body, ciphertext-only storage and AES-GCM tamper/AAD failures, service-role versus anon-key boundaries, metadata and per-owner DELETE, generic REST errors, API auth/tenant isolation, status/pair/disconnect across a simulated restart, real-mention and literal-fallback gates, group/chat/participant binding, DM defaults, self/history/duplicate filtering, and the backend send gate. No WhatsApp credentials or network interaction is used.

## Verification performed during follow-up

- Installed a temporary Node.js 22.15 runtime outside the project, generated `package-lock.json`, and ran `npm install --ignore-scripts --no-audit --no-fund` successfully. The lockfile pins Baileys 6.7.24 and uses a commit-pinned GitHub tarball override for `libsignal`, avoiding an implicit `git` executable requirement during npm install.
- `npm test`: **16/16 passed**, covering HTTP ownership, pairing lifecycle, encrypted Supabase REST storage, owner isolation, tamper detection, and message policy.
- `npm audit --omit=dev`: **0 vulnerabilities** for the installed production dependency tree.
- Baileys module initialization was attempted but could not complete in this sandbox: Node raised a WebAssembly/Undici out-of-memory error while importing the adapter. Thus no claim is made that the live Baileys socket or pairing-code request works here. A Render build/runtime validation and real linked-device test remain necessary before pairing.
- The preview UI's 7 Python source/contract tests pass. Its separate Node test runner also hit the sandbox's Undici WebAssembly memory error.

The previous initial note about Node being unavailable described the first review pass; Node was later downloaded temporarily for these checks. The Node runtime and install caches are not part of the deliverable.

## Environment and safe staging

Required settings (all outside source control):

- `SUPABASE_URL`: the Supabase project URL; production must use HTTPS.
- `SUPABASE_ANON_KEY`: the public anon key used only to call Supabase Auth; never a service-role key.
- `SUPABASE_SERVICE_ROLE_KEY`: the service-role secret used only by this server-side REST adapter. Keep it in Render's environment secret store; never put it in a browser, response, URL, log, or source file.
- `SESSION_ENCRYPTION_KEY`: a separate base64 encoding of a random 32-byte key from secret management. It must not equal the service-role key.
- `PORT`: supplied by Render.
- `ENABLE_PAIRING`: only the exact string `true` enables the pair route and Baileys adapter. Default/unset is off. This is a manual, staged switch, not auto-start.

Startup refuses missing/invalid authentication or vault settings. It never auto-restores or auto-starts a socket. After a process restart, a stored row is reported as `needs_disconnect` (with its last stored status and phone metadata); the owner must explicitly disconnect/delete that owner's row before another pairing. This deliberately avoids silently bringing a prior linked account online.

This candidate uses the already-created table `public.henymix_whatsapp_vault` in project `syxibiyrbgwsgghwwgej`. Its schema is owner-id PK/FK to `auth.users(id)` with cascade deletion, ciphertext-only `encrypted_state`, nullable `phone_number`, constrained `session_status`, and `updated_at`. The server filters every read, metadata/state update, and DELETE by the verified `owner_id`; initial upserts carry only that verified owner ID in the row body and use the primary-key `on_conflict=owner_id` target. The service role is used only by server code. Keep RLS enabled, do not add anon/authenticated client policies or grants, and grant table access only to `service_role`. These controls are assumptions the code relies on; this change does not query or alter the live database. Auth validation remains a separate `/auth/v1/user` request using only `SUPABASE_ANON_KEY`. Pairing codes are returned once and are never written to the table or logs. Explicit disconnect executes a DELETE filtered to that one verified owner.

Render's free web-service filesystem is ephemeral, offers no persistent disk, and the free service can sleep/restart. Session durability therefore comes from Supabase, not local files, but a sleeping/restarted process does not resume Baileys: this candidate intentionally does not auto-start or relink. A user may need to explicitly disconnect and pair again after a restart. Keep `ENABLE_PAIRING=false` unless a separate controlled test is approved; free hosting is not an always-on WhatsApp socket and should not be represented as such. The Supabase project/table, service-role secret, distinct encryption key, quotas/availability, backup/restore, key rotation, and operational recovery must also be managed. Do not log raw Baileys state, place the service-role key in the frontend, or store plaintext credentials. No persistent disk, paid Render add-on, deployment, or DB write was performed.

A Render blueprint for review should use a **free** web service, Node runtime, `npm install`/`npm start`, and leave `ENABLE_PAIRING` false; it is intentionally not included as a deployment action or created in Render. Do not upgrade, add a paid disk, or deploy without separate approval. Even with these environment variables, no assistant replies are active until a backend adapter is deliberately injected.

## Web frontend contract

Use the signed-in Supabase user's current access token in `Authorization: Bearer <access_token>`, JSON content type for pair, and `cache-control: no-store` on the client. Do **not** send a user ID or tenant ID; server ownership comes only from `/auth/v1/user` validation. Pairing code is shown only in the immediate successful response; don't save it in browser storage or application logs.

- `POST /v1/pair` with `{"phone":"+260XXXXXXXXX"}` (E.164). Returns `200 {"pairingCode":"…","expiresInSeconds":120,"status":"pairing"}`. Code is never returned from status. It is returned only to that authenticated request owner and is not stored by the worker. An existing active or saved session returns `409`; clear it first with owner-authorized disconnect. Disabled pairing returns `503`.
- `GET /v1/status` returns `{ "status":"disconnected" }`, an active in-process state such as `{ "status":"pairing","paired":false,"connected":false,"phone":"+260…","updatedAt":"ISO-8601" }` / `{ "status":"connected","paired":true,"connected":true,... }`, or after restart `{ "status":"needs_disconnect","storedStatus":"connected|pairing|disconnected","phone":"+260…","updatedAt":"ISO-8601" }`. Polling is appropriate. Pairing codes are never included.
- `POST /v1/disconnect` (no identity body) disconnects/logs out only the authenticated owner's socket and deletes their vault entry; returns `{ "status":"disconnected" }`.

Only those three routes are implemented. No frontend was modified.

## Reply and message policy

Default options are deny-all. Group replies require an injected owner-specific setting with `groupReplies: true`, an exact approved group JID and approved participant JID, plus a real WhatsApp `contextInfo.mentionedJid` matching the linked account. The literal `@Henymix` text fallback is separate and off unless `literalHenymixFallback: true` is explicitly set. DM replies default off; even with `dmReplies: true`, the exact chat must appear in `dmChats`. `getOptions(userId)` is an injected server-side configuration boundary; no browser-supplied options are trusted. Self messages, broadcast/status, history/non-`notify` upserts, duplicates in the in-process LRU window, messages without usable text, and messages from the linked account itself are ignored. Events are bound to the session owner's account, chat and participant. Do not enable broad group/DM policy.

A future assistant backend must receive only the accepted owner/chat/participant/message context, use an independently verified auth and tenant contract, impose size/time limits, and return plain reply text; `SessionManager` caps outbound text and only sends a response after the gate. It must not blindly proxy inbound text to the old edge function or accept caller-supplied owner IDs. The current worker has no configured assistant backend and does not send replies.

## Remaining production work / limits

1. Lock and audit Node/Baileys dependency tree (including upstream Git dependencies) in a controlled build.
2. Verify the new private encrypted Supabase vault against the actual project configuration and operationally design encryption-key rotation, access control, backups, concurrency, quotas, and recovery. No database writes or verification were performed as part of this candidate edit.
3. Add durable per-user group/participant/DM opt-in management and owner UX; settings are only injected test/server hooks now.
4. Integrate a verified assistant adapter and end-to-end test with the real app's authenticated token contract; no production assistant call has been verified.
5. Add persistence-backed deduplication, pairing expiry semantics/cleanup, reconnect/backoff policy, health checks, abuse controls, observability without sensitive data, and real provider-version compatibility checks.
6. Review TLS/proxy/rate-limit protections and stage/rollback. Confirm table RLS/grants and secret configuration in a controlled review; only after separate explicit approval, do a controlled linked-device pairing test. Never reuse or migrate unknown legacy sessions.

This is a staged candidate, not a complete deployed or production-ready integration.
